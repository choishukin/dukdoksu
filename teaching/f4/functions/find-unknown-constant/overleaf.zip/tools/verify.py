"""例題 3.7／練習題：以 sympy 驗算全部答案，並核對 main.tex 答案頁。
用法：python3 tools/verify.py"""
import os, re, sys
from sympy import symbols, Eq, solve, expand, factor, Rational as Q, simplify
x, a, b, k, p, q = symbols("x a b k p q")
HERE = os.path.dirname(os.path.abspath(__file__))
TEX = open(os.path.join(HERE, "..", "main.tex"), encoding="utf-8").read()
fails = []; n = 0
def check(name, cond, info=""):
    global n; n += 1
    if not cond: fails.append(name)
    print(("PASS " if cond else "FAIL ") + name + (f"   {info}" if info else ""))

# ---------- 例題 3.7 ----------
f = a*x**2 + 3*x - 2
aa = solve(Eq(f.subs(x, 1), 3), a)
check("例3.7(a) a = 2", aa == [2], aa)
f2 = f.subs(a, 2)
kk = solve(Eq(f2.subs(x, k), -3), k)
check("例3.7(b) k = -1/2 或 -1", set(kk) == {Q(-1, 2), -1}, kk)
check("例3.7 因式分解 2k²+3k+1 = (2k+1)(k+1)",
      expand((2*k + 1)*(k + 1) - (2*k**2 + 3*k + 1)) == 0)
check("例3.7 驗算 f(-1/2)=f(-1)=-3", f2.subs(x, Q(-1, 2)) == -3 and f2.subs(x, -1) == -3)

# ---------- 練習 ----------
ans = {}
# 1
f = 2*x + 5; ans[1] = (f.subs(x, 3), f.subs(x, -1))
# 2
g = x**2 - 4*x + 1; ans[2] = (g.subs(x, 2), g.subs(x, -1))
# 3
ans[3] = solve(Eq((a*x + 4).subs(x, 2), 10), a)[0]
# 4
ans[4] = solve(Eq((a*x**2 - x + 1).subs(x, 1), 5), a)[0]
# 5
ans[5] = solve(Eq((2*x**2 - 3*x + k).subs(x, 2), 5), k)[0]
# 6
aa = solve(Eq((a*x**2 + 5*x - 2).subs(x, 1), 5), a)[0]
f6 = 2*x**2 + 5*x - 2
ans[6] = (aa, set(solve(Eq(f6.subs(x, k), -2), k)))
# 7
ans[7] = set(solve(Eq((x**2 - 5*x + 6).subs(x, k), 2), k))
# 8
ans[8] = set(solve((2*x**2 - x - 3).subs(x, k), k))
# 9
ans[9] = solve([Eq(a + b - 6, 0), Eq(4*a + 2*b - 6, 4)], [a, b])
# 10
ans[10] = solve([Eq(b, 3), Eq(4 + 2*a + b, 11)], [a, b])
# 11
kk = solve(Eq((x**2 + k*x - 6).subs(x, 2), 0), k)[0]
f11 = x**2 + x - 6
ans[11] = (kk, set(solve(f11, x)))
# 12
s12 = solve([Eq(a + b + 2, 5), Eq(a - b + 2, 1)], [a, b])
ans[12] = (s12, (a*x**2 + b*x + 2).subs(s12).subs(x, 2))
# 13
s13 = solve([Eq(q, -1), Eq(2 + p + q, 4)], [p, q])
f13 = (2*x**2 + p*x + q).subs(s13)
other = [r for r in solve(Eq(f13.subs(x, k), f13.subs(x, -1)), k) if r != -1]
ans[13] = (s13, other)
# 14
aa = solve(Eq((a*x**2 - 5*x + 4).subs(x, 1), 0), a)[0]
# also check f(4)=0 with that a
f14 = aa*x**2 - 5*x + 4
ans[14] = (aa, factor(f14), f14.subs(x, 4))
# 15
ans[15] = set(solve(Eq((x**2 + (a - 1)*x - 2*a).subs(x, a), 0), a))

check("Q1 f(3)=11, f(-1)=3", ans[1] == (11, 3), ans[1])
check("Q2 g(2)=-3, g(-1)=6", ans[2] == (-3, 6), ans[2])
check("Q3 a=3", ans[3] == 3, ans[3])
check("Q4 a=5", ans[4] == 5, ans[4])
check("Q5 k=3", ans[5] == 3, ans[5])
check("Q6 a=2; k=0 或 -5/2", ans[6] == (2, {0, Q(-5, 2)}), ans[6])
check("Q7 k=1 或 4", ans[7] == {1, 4}, ans[7])
check("Q8 k=3/2 或 -1", ans[8] == {Q(3, 2), -1}, ans[8])
check("Q9 a=-1, b=7", ans[9] == {a: -1, b: 7}, ans[9])
check("Q10 a=2, b=3", ans[10] == {a: 2, b: 3}, ans[10])
check("Q11 k=1; x=-3 或 2", ans[11] == (1, {-3, 2}), ans[11])
check("Q12 a=1, b=2; f(2)=10", ans[12] == ({a: 1, b: 2}, 10), ans[12])
check("Q13 p=3, q=-1; k=-1/2", ans[13] == ({p: 3, q: -1}, [Q(-1, 2)]), ans[13])
check("Q14 a=1; (x-1)(x-4); f(4)=0",
      ans[14][0] == 1 and expand(ans[14][1] - (x - 1)*(x - 4)) == 0 and ans[14][2] == 0, ans[14])
check("Q15 a=0 或 3/2", ans[15] == {0, Q(3, 2)}, ans[15])

# ---------- 核對答案頁文字 ----------
body = TEX[TEX.index(r"\sect{五、答案}"):]
need = [
    r"f(3)=11", r"f(-1)=3",
    r"g(2)=-3", r"g(-1)=6",
    r"$a=3$", r"$a=5$", r"$k=3$",
    r"$a=2$", r"k=0", r"-\dfrac{5}{2}",
    r"$k=1$ 或 $k=4$",
    r"\dfrac{3}{2}", r"$k=-1$",
    r"$a=-1$，$b=7$",
    r"$a=2$，$b=3$",
    r"$k=1$", r"$x=-3$ 或 $x=2$",
    r"$a=1$，$b=2$", r"$f(2)=10$",
    r"$p=3$，$q=-1$", r"-\dfrac{1}{2}",
    r"$a=1$", r"(x-1)(x-4)",
    r"$a=0$ 或 $a=\dfrac{3}{2}$",
]
miss = [s for s in need if s not in body]
check("答案頁含全部 15 題結果", not miss, miss)

# 例題答案框
def fa_list(t):
    out, i = [], 0
    while True:
        i = t.find(r"\fa{", i)
        if i < 0: return out
        j = i + 4; d = 1
        while d:
            d += {"{": 1, "}": -1}.get(t[j], 0); j += 1
        out.append(t[i + 4:j - 1]); i = j
fas = fa_list(TEX)
check("例題答案框", fas == ["2", r"-\dfrac{1}{2}", "-1"], fas)

print(f"\n{n} checks, {len(fails)} failures" + (": " + ", ".join(fails) if fails else ""))
sys.exit(1 if fails else 0)
