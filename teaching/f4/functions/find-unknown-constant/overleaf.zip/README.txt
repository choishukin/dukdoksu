中四數學｜例題 3.7「求函數中的未知常數」教學材料
來源：HMM2E（聯合培生）4A Ch.3 例題 3.7（程度 1）

檔案
- lesson.tex ........ 教案（1 頁）
- main.tex .......... 學生筆記（3 頁：重點＋例題、練習、答案）
- preamble.tex ...... 共用導言（XeLaTeX + xeCJK、Noto CJK TC）
- latexmkrc ......... 指定 XeLaTeX
- tools/verify.py ... 以 sympy 驗算例題及 15 道練習題（21 項檢查）

編譯
- latexmk lesson.tex
- latexmk main.tex
- Overleaf：Compiler 選 XeLaTeX；可分別以 lesson.tex 或 main.tex 為主文件

驗算
- python3 tools/verify.py
